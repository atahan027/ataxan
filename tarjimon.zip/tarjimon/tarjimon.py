import telebot
from googletrans import Translator

# Telegram bot tokenini kiritish
BOT_TOKEN = '7609553908:AAEfQz7ql4IrwEoX-xcQzzJTU2sZ6LTst2I'

bot = telebot.TeleBot(BOT_TOKEN)
translator = Translator()

# Foydalanuvchi ma'lumotlarini vaqtincha saqlash uchun
user_data = {}

# Tarjima qilish mumkin bo'lgan tillar ro'yxati
languages = {
    'en': 'Ingliz tili',
    'uz': 'O‘zbek tili',
    'ru': 'Rus tili',
    'fr': 'Fransuz tili',
    'de': 'Nemis tili',
    'es': 'Ispan tili',
    'it': 'Italyan tili',
    'tr': 'Turk tili',
    'zh-cn': 'Xitoy tili (soddalashtirilgan)',
}

@bot.message_handler(commands=['start'])
def start_message(message):
    bot.reply_to(message, "Salom! Tarjima qilinadigan so'zni yozing:")

@bot.message_handler(func=lambda message: True)
def get_text(message):
    chat_id = message.chat.id
    user_data[chat_id] = {'text': message.text}  # Foydalanuvchi matnini saqlash
    markup = telebot.types.ReplyKeyboardMarkup(one_time_keyboard=True, resize_keyboard=True)
    for lang_code, lang_name in languages.items():
        markup.add(lang_name)
    bot.send_message(chat_id, "Qaysi tilga tarjima qilmoqchisiz?", reply_markup=markup)
    bot.register_next_step_handler(message, select_language)

def select_language(message):
    chat_id = message.chat.id
    selected_language = None
    for lang_code, lang_name in languages.items():
        if message.text == lang_name:
            selected_language = lang_code
            break
    
    if selected_language:
        user_data[chat_id]['language'] = selected_language
        original_text = user_data[chat_id]['text']
        try:
            translated_text = translator.translate(original_text, dest=selected_language).text
            bot.send_message(chat_id, f"Tarjima: {translated_text}")
        except Exception as e:
            bot.send_message(chat_id, f"Tarjima jarayonida xatolik yuz berdi: {e}")
    else:
        bot.send_message(chat_id, "Noto'g'ri tilni tanladingiz. Qaytadan boshlang /start.")

# Botni ishga tushirish
print("Bot ishga tushirildi...")
bot.polling()
